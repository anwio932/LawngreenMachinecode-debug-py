# Python program with 2 open
var = "Double value"
sumvalue = var + 4

def dosomething(valuetocheck):
  if valuetocheck > 4:
    print(" value is greater than 4")

Var =  int(input("Enter a number greater than 0"))
checkvalue(var)